=== AVR Web Consulting ===
Contributors: avrwebconsulting
Requires at least: 6.0
Tested up to: 6.7
Requires PHP: 7.4
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==
Modern, high-performance WordPress theme for AVR Web Consulting - Digital Marketing, AI SEO, GEO, AEO, LLMO, and Web Development agency. Fully responsive, customizable, and perfectly matched with the codebase.

== Installation ==
1. In your WordPress admin, go to Appearance > Themes.
2. Click "Add New Theme" and then click "Upload Theme".
3. Choose the "avr-web-consulting.zip" file and click "Install Now".
4. After installation, click "Activate".
5. Customize your company phone, email, WhatsApp, and office address under Appearance > Customize > AVR Theme Customizer.

== Features ==
- Bulletproof logo sizing: Logo is neatly constrained (44px on desktop, 32px on mobile) across all viewports.
- Video hero with poster fallback and ambient cyan lighting.
- Complete 7-category navigation with accessible dropdowns.
- Interactive mobile drawer with hamburger toggle.
- 10 interactive FAQs with smooth accordion expand/collapse.
- Technology badges, metric highlight bands, and service cards.
- Contact form with AJAX validation and WhatsApp/Call quick buttons.
- Fully compatible with Gutenberg, classic editor, and customizer.
